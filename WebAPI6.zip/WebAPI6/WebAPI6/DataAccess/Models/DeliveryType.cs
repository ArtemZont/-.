﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models
{
    public partial class DeliveryType
    {
        public DeliveryType()
        {
            Orders = new HashSet<Order>();
        }

        public int DeliveryTypeId { get; set; }
        public string Type { get; set; } = null!;
        public bool IsDeleted { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
