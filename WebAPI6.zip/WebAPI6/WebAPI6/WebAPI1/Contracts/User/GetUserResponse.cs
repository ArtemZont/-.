﻿namespace WebAPI1.Contracts.User
{
	public class GetUserResponse
	{
		public int UserId { get; set; }
		public string Login { get; set; } = null!;
		public string Password { get; set; } = null!;
		public string Mail { get; set; } = null!;
		public int RoleId { get; set; }
		public string Name { get; set; } = null!;
		public string Adress { get; set; } = null!;
		public bool IsDeleted { get; set; }
	}
}
